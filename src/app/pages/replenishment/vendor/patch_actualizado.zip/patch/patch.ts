import { Component, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, IonList, LoadingController, ModalController, ToastController, Config } from '@ionic/angular';
import { ConferenceData } from '../../../../providers/conference-data';
import { UserData } from '../../../../providers/user-data';
import { Session } from '../../../../interfaces/session';
import { UtilService } from '../../../../services/util.service';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { UserService } from '../../../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PhotoService } from '../../../../services/asset/photo.service';
import { OcrService } from '../../../../services/ai/ocr.service';
import { CcoService } from '../../../../services/cc/cco.service';
import { WithdrawnService } from '../../../../services/replenishment/withdrawn.service';
import { GlppricesService } from '../../../../services/replenishment/glpprices.service';
import { Cco,CcoMap } from '../../../../interfaces/cco';

@Component({
  selector: 'page-patch',
  templateUrl: 'patch.html',
  styleUrls: ['./patch.scss'],
})
export class PatchPage {

  ios: boolean;
  hasOwner:boolean=false;
  segment = 'all';
  showSearchbar: boolean;
  opportunities = [];
  storedObject: any;
  posOrders: any[] = [];
  posOrderLineList: any[] = [];
  pendingCommands: any[] = [];
  deliveredList: any[] = [];
  filteredProductList: any[] = [];
  maxQtyDeliveredItems: any[] = [];
  queryText:any
  mesas: any[] = [];
  activeSession: Session | null = null;
  sessionId: number | null = null;
  searchSubject = new Subject<string>();
  todayDate:any;
  form!: FormGroup;
  replenishmentList: any[] = [];
  replenishment:any;
  //assetSupplyProduct:any;
  movement:any;
  cco:any;
  //imported:any;
  glppricesList: any[] = [];
  numero!: number;
  cents!: number;
  lastGlpprice: any = null;
  lastImportedPrice: any = null;
  ocrSuccess:boolean = false;

  constructor(
    public alertCtrl: AlertController,
    public confData: ConferenceData,
    public loadingCtrl: LoadingController,
    public modalCtrl: ModalController,
    public router: Router,
    public toastCtrl: ToastController,
    public user: UserData,
    public config: Config,
    private utilService:UtilService,
    private userService: UserService,
    private fb: FormBuilder ,
    private photoService: PhotoService,
    private ocrService : OcrService,
    private withdrawnService : WithdrawnService,
    private ccoService : CcoService,
    private glpPricesService: GlppricesService
  ) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state?.item) {
      this.movement = navigation.extras.state.item;
      this.uploadedUrl=this.movement.data.img;
      //this.imported=this.movement.id_replenishment_product;
    } else {
      // Si recargaron la página, puedes cargar el item desde un servicio o API
      console.warn('No se recibió item por NavigationExtras.state');
    }
    console.log("Item recibidox:", this.movement);
  }

  ngOnInit(){
    this.form = this.fb.group({
      id: [this.movement?.id ?? null],
      fecha: [this.movement?.data.date ?? ''],
      name: [this.movement?.data.name ?? ''],
      ticket: [this.movement?.data.ticket ?? ''],
      sello1: [this.movement?.data.seal[0] ?? ''],
      sello2: [this.movement?.data.seal[1] ?? ''],
      sello3: [this.movement?.data.seal[2] ?? ''],
      kg: [this.movement?.data?.kg ?? ''],
      rotogage: [this.movement?.data?.rotogage ?? 0], 
      psi: [this.movement?.data?.psi ?? 0], 
      imported: [this.movement?.data?.id_replenishment_product ?? 0], 
      //price: [this.movement?.data?.price ?? 0], 
    });
    this.ccoName=this.ccoService.getName(this.movement.data.name); 
    this.searchSubject.pipe(
        debounceTime(300),
        distinctUntilChanged()
      ).subscribe(text => {
        this.applyFilter(text);
      });
     this.loadGlpPrice();
  }

  ionViewWillEnter() {
    this.form.patchValue({
      id: this.movement?.id ?? null,
      fecha: this.movement?.data?.date ?? '',
      name: this.movement?.data?.name ?? '',
      ticket: this.movement?.data?.ticket ?? '',
      sello1: this.movement?.data?.seal?.[0] ?? '',
      sello2: this.movement?.data?.seal?.[1] ?? '',
      sello3: this.movement?.data?.seal?.[2] ?? '',
      kg: this.movement?.data?.kg ?? '',
      rotogage: this.movement?.data?.rotogage ?? 0,
      psi: this.movement?.data?.psi ?? 0,
      imported: this.movement?.data?.id_replenishment_product ?? 0,
      //price: this.movement?.data?.price ?? 0
    });
  }

  resetForm(): void {
    this.uploadedUrl='';
    this.form.reset({
      id: 0,
      categ: null,
      name: '',
      bop: '',
      barcode: '',
      qty: 1,
      um: null,
      target: 0,
      reorder: 0,
      minimum: 0,
    });
    this.uploadProgress = 0; 
    this.uploadedUrl= null;
    this.uploading = false;
  }

  slideOpts = {
    initialSlide: 0,
    slidesPerView: 1,
    speed: 300
  };

  updateSchedule(){}

  ccoList:any[]=[];
  movement2:any;
  hasTwin:Boolean=false;
  ionViewDidEnter() {
    //this.resetForm();
    this.loadCcos();
    this.getAllPrices();
    this.getAllCco();   
  }

  ccoMap:CcoMap={};                
  loadCcos() {
    this.ccoService.load().subscribe({
      next:(map)=>{
        this.ccoMap=map;
        this.ccoService.debugMapping(this.filteredList);
        this.getCco2();
      },
      error:(err)=>{
        console.error('Error loading ccos',err);
      }
    });
  }

  getCco2(){
    if(this.movement.data.twin && Number(this.movement.data.twin)>0){
      this.hasTwin=true;
      this.withdrawnService.getById(this.movement.data.twin).subscribe({
        next: res=> {
          this.movement2=res[0];
          this.cco2Id=this.movement2.data.name;
          this.cco2Name=this.ccoMap[this.cco2Id]?.name;
        }
      })
    }  
  }

  onSearch(text: string) {
    this.applyFilter(text);
  }

  applyFilter(text: string) {
    if (!text || text.trim() === '') {
      this.filteredList = this.ccoList;
      return;
    }
    const search = this.normalize(text);
    console.log('textNoprmalized',search);
    console.log('ccoList',this.ccoList);
    this.filteredList = this.ccoList.filter(item => {
      const name = item?.data?.name || '';
      const normalizedName = this.normalize(name);
      return normalizedName.includes(search);
    });
  }

  normalize(value: string): string {
    return value
      .toLowerCase()
      .replace(/\s+/g, '')        // quitar espacios
      .replace(/[^a-z0-9]/g, '')  // quitar símbolos
      .replace(/0/g, 'o')         // OCR fix
      .replace(/1/g, 'i');        // OCR fix
  }

  formatFechaLatam(dateInput: string | Date | number): string {
    if (!dateInput) return '';
    const date = new Date(dateInput);
    const opciones: Intl.DateTimeFormatOptions = {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    };
    const fechaTexto = new Intl.DateTimeFormat('es-ES', opciones).format(date);
    let horas = date.getHours();
    const minutos = String(date.getMinutes()).padStart(2, '0');
    const segundos = String(date.getSeconds()).padStart(2, '0');
    const ampm = horas >= 12 ? 'PM' : 'AM';
    horas = horas % 12;
    if (horas === 0) horas = 12; // 12 AM o 12 PM en lugar de 0
    const horasTexto = String(horas).padStart(2, '0');
    return `${fechaTexto} ${horasTexto}:${minutos}:${segundos} ${ampm}`;
  }

  uploadProgress = 0;
  uploadedUrl: string | null = null;
  uploading = false;

  /*async takePhotoAndUpload() {*/
    /*this.uploading = true;*/
    /*this.uploadProgress = 0;*/
    /*this.uploadedUrl = null;*/
    /*const base64Image = await this.photoService.takePicture();*/
    /*if (!base64Image) {*/
      /*this.uploading = false;*/
      /*console.error('No se pudo obtener la imagen');*/
      /*return;*/
    /*}*/
    /*const { progress$, url$ } = this.photoService.uploadBase64Image(base64Image,'fotos');*/
    /*progress$.subscribe({*/
      /*next: (p) => this.uploadProgress = p,*/
      /*error: (err) => {*/
        /*console.error('Error subiendo imagen', err);*/
        /*this.uploading = false;*/
      /*}*/
    /*});*/
    /*url$.subscribe({*/
      /*next: (url) => {*/
        /*this.uploadedUrl = url;*/
        /*// aquí llamas el OCR*/
        /*this.launchOcr(url);*/
      /*},*/
      /*error: (err) => {*/
        /*console.error('Error obteniendo URL', err);*/
      /*},*/
      /*complete: () => {*/
        /*this.uploading = false;*/
      /*}*/
    /*});*/
  /*}*/

  /*async pickImageAndUpload() {*/
    /*this.uploading = true;*/
    /*this.uploadProgress = 0;*/
    /*this.uploadedUrl = null;*/
    /*const base64Image = await this.photoService.pickImage();*/
    /*if (!base64Image) {*/
      /*this.uploading = false;*/
      /*return;*/
    /*}*/
    /*const { progress$, url$ } = this.photoService.uploadBase64Image(base64Image,'fotos');*/
    /*progress$.subscribe(p => this.uploadProgress = p);*/
    /*url$.subscribe({*/
      /*next: (url) => {*/
        /*this.uploadedUrl = url;*/
        /*// lanzar OCR cuando la URL esté disponible*/
        /*this.launchOcr(url);*/
      /*},*/
      /*error: (err) => {*/
        /*console.error('Error upload', err);*/
        /*this.uploading = false;*/
      /*},*/
      /*complete: () => {*/
        /*this.uploading = false;*/
      /*}*/
    /*});*/
  /*}*/


  imageRaw:string | null= null;
  ocrResponse:any;
  vendorDate:any='2000-01-01T00:01:00';;
  launchOcr(url: string) {
    console.time('time');
    this.startTimer();
    this.ocrSuccess = true;
    this.imageRaw=url;
    this.postImage(this.imageRaw);
    this.ocrService.postVendor(url).subscribe({
      next: (res) => {
        this.stopTimer();   
        this.ocrSuccess = false;
        console.log('ocr response',res)
        console.timeEnd('time');
        this.ocrResponse = res;
        this.ccoName="TCSU "+res?.data?.isotanq;
        this.ccoId=this.ccoService.getIdByName(this.ccoName);     
        const normalizedDate = this.normalizeOCRDate(res?.data?.date);
        const seals = res?.data?.seal ?? [];
        // actualizar movement
        this.movement.data = {
          ...this.movement.data,
          date: normalizedDate,
          kg: Number(res?.data?.kg ?? 0),
          ticket: res?.data?.ticket ?? 0,
          psi: Number(res?.data?.psi ?? 0),
          rotogage: Number(res?.data?.rotogage ?? 0),
          seal: seals
        };
        //actualizar form para que UI refleje los cambios
        this.form.patchValue({
          fecha: normalizedDate,
          kg: Number(res?.data?.kg ?? 0),
          ticket: res?.data?.ticket ?? 0,
          psi: Number(res?.data?.psi ?? 0),
          rotogage: Number(res?.data?.rotogage ?? 0),
          sello1: seals[0] ?? '',
          sello2: seals[1] ?? '',
          sello3: seals[2] ?? ''
        });
        console.log("movement actualizado:", this.movement);
        this.vendorDate=this.ocrResponse.data.date; 
      },
      error: (err) => {
        console.error('Error OCR:', err);
      }
    });
  }
  
  isValidMovementDate(value: any): boolean {
    if (typeof value !== 'string' || !value.trim()) return false;
    const parsed = new Date(value);
    return !Number.isNaN(parsed.getTime()) && parsed.getFullYear() > 2024;
  }

  updateMovementFromForm() {
    const f = this.form.value;
    this.movement.data = {
      ...this.movement.data,
      date: f.fecha,
      name: this.ccoName,
      ticket: f.ticket,
      kg: Number(f.kg),
      psi: Number(f.psi),
      rotogage: Number(f.rotogage),
      seal: [f.sello1, f.sello2, f.sello3].filter(Boolean)
    };
  }

  patch() {
    this.updateMovementFromForm();
    this.movement.data.img = this.uploadedUrl;
    //this.movement.data.date=this.vendorDate;
    //const itemPrice = this.getGlpPriceItemByDate(this.movement.data.date, 1);
    //console.log("itemPrice",itemPrice)
    console.log("movement.data a enviar",this.movement.data)
    const date = this.movement.data.date;
    if (!this.isValidMovementDate(date)) {
      this.utilService.presentToast('fecha / año no valido','danger',800)
      return;
    }
    /*if(itemPrice?.data) {*/
      /*const { price, cents } = itemPrice.data;*/
      /*this.movement.data.price = `${price}.${cents}`;*/
    /*}else {*/
      /*console.warn("No se encontró un precio válido para la fecha", this.movement.data.date);*/
      /*this.utilService.presentToast('Revise la fecha ingresada Año-mes-dia','danger',2000)*/
    /*}*/
    //const cop = itemPrice.data.price;
    //const cents = itemPrice.data.cents;
    //this.movement.data.price=`${cop}.${cents}`;
    this.movement.data.id_replenishment_product=1;
    let payload = this.movement.data;
    payload.name = this.ccoId;
    console.log("payload to patch =>", payload);
    this.withdrawnService.patch(this.movement.id, payload).subscribe({
      next: (response) => {
        console.log("Withdrawn patch response", response);
        this.utilService.presentToast("registro actualizado exitosamente","success",1000);
          this.router.navigate(['/app/tabs/replenishment-withdrawn-getall'],   { replaceUrl: true });  
          /*const twinId = Number(payload?.twin || 0);*/
          /*if (twinId < 1) {*/
            /*this.finishPatch();*/
            /*return;*/
          /*}*/
          /*this.movement2.data.imgscale = this.uploadedUrl;*/
          /*this.movement2.data.wticket = this.movement.data.wticket;*/
          /*this.movement2.data.wgross = this.movement.data.wgross;*/
          /*this.movement2.data.wnet = this.movement.data.wnet;*/
          /*this.movement2.data.wtare = this.movement.data.wtare;*/
          /*this.withdrawnService.patch(this.movement2.id, this.movement2.data).subscribe({*/
            /*next: (response2) => {*/
              /*console.log("Twin patch response", response2);*/
              /*this.finishPatch();*/
            /*},*/
            /*error: (err) => {*/
              /*console.error("Twin patch error", err);*/
              /*this.utilService.presentToast("Error actualizando el movimiento twin", "danger", 1500);*/
            /*}*/
          /*});*/
      },
      error: (err) => {
     console.error("Withdrawn patch error", err);
      }
    });
  }
 
  private finishPatch() {
    this.resetForm();
    this.utilService.presentToast("Actualizado correctamente", "success", 1000);
    this.router.navigate(['/app/tabs/replenishment-withdrawn-getall'], { replaceUrl: true });
  }

  normalizeOCRDate(dateStr: string): string | null {
    if (!dateStr) return null;
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) {
      console.warn("Fecha OCR inválida:", dateStr);
      //imported: this.movement?.data?.id_replenishment_product ?? 0,
      return null;
    }
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const mi = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}`;
  }

  filteredList: any[] = [];     //lista filtrada

  getAllCco(){
    this.ccoService.getAll().subscribe({
      next: (response: any[]) => {
        console.log('cco List', response);
        this.ccoList = response;
      },
      error: (err: any) => {
        console.error('Error cargando CCO', err);
      }
    });
  }
  ccoName: string = '';   // nombre a mostrar
  ccoId: number = 0;   // id cco seleccionado a mostrar
  selectCco(item: any) {
    this.cco = item;
    this.ccoName = item.data.name;
    this.ccoId = item.id;
    //actualizar movement (muy importante en tu flujo)
    if (this.movement?.data) {
      this.movement.data.name = item.id;
    }
    console.log('item pasado:', item);
    console.log('cco name:', this.ccoName);
    console.log('cco id:', this.ccoId);
    this.filteredList=[];
  }

  /*---- CCO2------ */
  filteredList2: any[] = [];     //lista filtrada
  onCco2Search(text: string) {
    console.log('text to search',text)
    this.applyFilter2(text);  
  }  
  applyFilter2(text: string) {
    if (!text || text.trim() === '') {
      this.filteredList2 = this.ccoList;
      return;
    }
    const search = text.trim().toLowerCase();
    this.filteredList2= this.ccoList.filter(item => {
      const name = (item?.data?.name || '').toLowerCase();
      return name.includes(search);
    });
    console.log('filteredList2', this.filteredList2);
  }

  cco2Name: string = '';   // nombre a mostrar
  cco2Id: number = 0;   // id cco seleccionado a mostrar
  select2Cco(item: any) {
    this.cco2 = item;
    this.cco2Name = item.data.name;
    this.cco2Id = item.id;
    //actualizar movement (muy importante en tu flujo)
    console.log('item pasado cco2:', item);
    console.log('cco2 name:', this.cco2Name);
    console.log('cco2 id :', this.cco2Id);
    this.filteredList2=[];
  }
  cco2:any;  
  isotanq2:any;

  isImportedGlp(ev: any) {
    const checked = ev.detail.checked;
    if(checked>0){
      this.movement.data.id_replenishment_product = checked ? 2 : 1;
    }
    console.log('id_replenishment_product nuevo =>', this.movement.data.id_replenishment_product);
  }

  getAllPrices() {
    this.glpPricesService.getAll().subscribe({
      next: (response) => {
        this.glppricesList = response.slice().reverse();
        console.log("pricelist",this.glppricesList)
      }
    });
  }

  glpPriceList: any[] = []; 
  loadGlpPrice() {              
     this.glpPricesService.getAll().subscribe({ 
        next: (res) => {       
          console.log('glpPrices',res);    
          this.glpPriceList = res;
        }, 
        error: (err) => {      
          console.error(' Error al cargar glpPrices:', err); 
        } 
      }); 
  } 

  getGlpPriceItemByDate(date:string,idReplenishmentProduct:number):any|null {
    console.log('getGlppriceItemByDate',date)
    console.log('getGlppriceItemByDate',idReplenishmentProduct)
    const target=new Date(date).getTime();
    for(const item of this.glpPriceList) {
      const data=item?.data;
      if(!data)
        continue;
      if(data.id_replenishment_product!==idReplenishmentProduct)
        continue;
      const init=new Date(data.init).getTime();
      const end=new Date(data.end).getTime();
      if(target>=init && target<=end)
        return item;
    }
    return null;
  }

  /*onChange(event: any) {*/
    /*console.log('event',event.detail.value);*/
    /*this.vendorDate=event.detail.value;*/
    /*this.movement.data.date=event.detail.value;*/
    /*console.log('movement.data.date',this.movement.data.date);*/
  /*}*/

  private timerId: any = null;
  startTimer(): void {       
    this.stopTimer();
    let seconds = 89;        
    console.log('1:29');     
    this.timerId = setInterval(() => {
      const minutes = Math.floor(seconds / 60);
      const secs = seconds % 60;      
      console.log(`${minutes}:${secs.toString().padStart(2, '0')}`); 
      if (seconds === 0) {   
        this.stopTimer();    
        return;              
      }
      seconds--;
    }, 1000);
  }   
  stopTimer(): void {        
    if (this.timerId !== null) {      
      clearInterval(this.timerId);    
      this.timerId = null;   
    }     
  }       

  extractShipName(text: string): string {
    return text?.replace(/^IMO\s+\d+\s*/i, '').trim() ?? ''; 
  }  


  async takePhotoAndUpload(): Promise<void> { 
    if (this.uploading) return;
    this.uploading = true;
    try {
      const base64Image = await this.photoService.takePicture();
      if (!base64Image) {
        this.uploading = false;
        return;
      }
      this.launchOcr(base64Image);
    } catch (error) {
      console.error('Error capturando imagen:', error);
      this.uploading = false;
    }
  }
  

  /*launchOcr(base64Image: string): void {*/
    /*console.time('OCR_PROCESS');*/
    /*console.log('Base64 length:', base64Image.length);*/
    /*console.log('Base64 prefix:', base64Image.substring(0, 30));*/
    /*this.ocrService.postVendor(base64Image).subscribe({*/
      /*next: (response) => {*/
        /*console.timeEnd('OCR_PROCESS');*/
        /*console.log('OCR JSON COMPLETO:', response);*/
      /*},*/
      /*error: (error) => {*/
        /*console.timeEnd('OCR_PROCESS');*/
        /*console.error('OCR ERROR:', {*/
          /*status: error.status,*/
          /*message: error.message,*/
          /*response: error.error*/
        /*});*/
      /*}*/
    /*});*/
  /*}*/
    




  async postImage(image:any) {
    const base64Image = image;
    if (!base64Image) {
      this.uploading = false;
      console.error('No se pudo obtener la imagen');
      return;
    }
    const { progress$, url$ } = this.photoService.uploadBase64Image(base64Image,'fotos');
    progress$.subscribe({
      next: (p) => this.uploadProgress = p,
      error: (err) => {
        console.error('Error subiendo imagen', err);
        this.uploading = false;
      }
    });
    url$.subscribe({
      next: (url) => {
        this.uploadedUrl = url;
      },
      error: (err) => {
        console.error('Error obteniendo URL', err);
      },
      complete: () => {
        this.uploading = false;
      }
    });
  }




  //uiDate:any='2011-11-11T11:11:11.776966-05:00';
  //uiDate:any=this.localDateTime(new Date());
  maxDate = this.localDateTime(new Date());
  minDate = this.getMinDate();
  years = Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i);
  datePickerOpen = false;
  pendingDate = '2011-11-11T11:11:11.776966-05:00';

  toDateTimeValue(value: any): string {
    if (!value) return '';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : date.toISOString();
  }
  localDateTime(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}` +
      `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  }
  getMinDate(): string {
    const date = new Date();
    date.setFullYear(date.getFullYear()-2);
    return this.localDateTime(date);
  }
  get selectedYear(): number { return Number((this.pendingDate || '').slice(0, 4)); }
  changeYear(event: any): void {
    const year = Number(event?.detail?.value);
    if (!this.years.includes(year)) return;
    const date = new Date(this.pendingDate);
    if (Number.isNaN(date.getTime())) return;
    const day = date.getDate();
    date.setDate(1);
    date.setFullYear(year);
    date.setDate(Math.min(day, new Date(year, date.getMonth()+1, 0).getDate()));
    const value = this.localDateTime(date);
    this.pendingDate = value < this.minDate ? this.minDate : value > this.maxDate ? this.maxDate : value;
  }
  openDatePicker(): void {
    this.maxDate = this.localDateTime(new Date());
    this.minDate = this.getMinDate();
    this.years = Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i);
    const value = this.toDateTimeValue(this.movement.data.date);
    const date = value ? this.localDateTime(new Date(value)) : this.maxDate;
    this.pendingDate = date < this.minDate ? this.minDate : date > this.maxDate ? this.maxDate : date;
    this.datePickerOpen = true;
  }
  closeDatePicker(): void { this.datePickerOpen = false; }
  onPendingDateChange(event: any): void {
    const value = event?.detail?.value;
    if (typeof value === 'string' && value) {
      this.pendingDate = value < this.minDate ? this.minDate : value > this.maxDate ? this.maxDate : value;
    }
  }
  confirmDatePicker(): void {
    this.onChange({ detail: { value: this.pendingDate } });
     console.log('pending date',this.pendingDate)
    this.closeDatePicker();
  }
  onChange(event: any): void {
    const value = event?.detail?.value;
    if (typeof value !== 'string' || !value) return;
    //this.uiDate = value;
    this.movement.data.date = value;
    this.form?.patchValue({ fecha: value });
  }

  async pickImageAndUpload(): Promise<void> {
    if (this.uploading) return;
    this.uploading = true;   
    try {   
      const base64Image = await this.photoService.pickImage();
      if (!base64Image) {    
        this.uploading = false;
        return;
      }     
      this.launchOcr(base64Image);  
    } catch (error) {        
      console.error('Error seleccionando imagen:', error);
      this.uploading = false;
    } 
  }   
        


}




