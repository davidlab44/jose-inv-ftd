GETALL - FILTRO POR created_at

1. Reemplazar los archivos del directorio getall/ en el componente existente.
2. Abrir el archivo original src/app/services/replenishment/withdrawn.service.ts.
3. Copiar el método de service_patch/withdrawn.service.METODO.txt DENTRO de la clase WithdrawnService.
   No reemplazar el servicio completo: no se suministró su código fuente.
4. La carga inicial consulta desde el primer día del mes actual hasta el final del día de hoy.
5. Los controles de rango, flechas y segmentos consultan created_at en el servidor.
6. El límite superior es exclusivo (medianoche del día posterior), evitando pérdidas
   de registros con fracciones de segundo y desfases horarios.
7. Se conserva orden descendente por id, parejas, búsqueda y visualización de celdas.

NOTA: Los controles actuales seleccionan días del año en curso; no navegan a años anteriores.
Si el backend PostgREST limita el número de filas por petición (p. ej. 1000),
se necesitaría paginación para intervalos que excedan ese límite.
