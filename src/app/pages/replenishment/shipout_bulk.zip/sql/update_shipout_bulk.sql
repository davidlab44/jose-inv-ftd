-- Ejecutar UNA VEZ en PostgreSQL, desde psql.
-- Actualiza exclusivamente data.shipout en los registros que aún tienen shipout=3.
-- Es una sola operación atómica, evitando sobrescribir el resto del JSONB.
CREATE OR REPLACE FUNCTION public.update_withdrawn_shipout_bulk(
  p_ids bigint[],
  p_ship_id integer
)
RETURNS TABLE(id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
  requested_count integer;
  changed_count integer;
BEGIN
  IF p_ship_id IS NULL OR p_ship_id <= 0 OR p_ship_id = 3 THEN
    RAISE EXCEPTION 'ship_id invalido: %', p_ship_id;
  END IF;
  SELECT count(DISTINCT x) INTO requested_count FROM unnest(p_ids) AS x;
  IF requested_count = 0 THEN
    RAISE EXCEPTION 'Lista de IDs vacia';
  END IF;
  -- Bloquear filas objetivo y rechazar cambios concurrentes / IDs inexistentes.
  PERFORM 1 FROM public.withdrawn w WHERE w.id = ANY(p_ids) ORDER BY w.id FOR UPDATE;
  SELECT count(*) INTO changed_count
    FROM public.withdrawn w
    WHERE w.id = ANY(p_ids) AND w.data->>'shipout' = '3';
  IF changed_count <> requested_count THEN
    RAISE EXCEPTION 'Uno o mas registros no existen o ya no tienen shipout=3 (% de %)', changed_count, requested_count;
  END IF;
  RETURN QUERY
    UPDATE public.withdrawn w
    SET data = jsonb_set(w.data, '{shipout}', to_jsonb(p_ship_id), true)
    WHERE w.id = ANY(p_ids) AND w.data->>'shipout' = '3'
    RETURNING w.id;
END;
$$;
-- IMPORTANTE: controlar los permisos EXECUTE de la funcion segun el rol PostgREST.
-- Si PostgREST no descubre la RPC inmediatamente: NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload schema';
