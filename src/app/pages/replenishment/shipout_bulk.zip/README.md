# Shipout Bulk - componente independiente

Basado en `getall_created_at_mes.zip` sin modificar el componente original `getall`.

## Instalación

1. Copiar `shipout-bulk/` al mismo nivel de carpetas que `getall/` (imports relativos originales).
2. Añadir ruta lazy-loaded en el routing padre, por ejemplo:
   `{ path: 'shipout-bulk', loadChildren: () => import('./shipout-bulk/shipout-bulk.module').then(m => m.ShipoutBulkModule) }`
   Adaptar la ruta relativa a tu estructura.
3. Mantener `WithdrawnService.getIntervalByCreatedAt(since, untilExclusive)` de la versión anterior.
4. Copiar `service_patch/withdrawn.service.METODOS.ts.txt` dentro de `WithdrawnService`.
5. Ejecutar `sql/update_shipout_bulk.sql` en PostgreSQL. Revisar permisos de ejecución RPC.

## Funcionamiento

- Consulta por `created_at` en el intervalo del mes actual y permite navegar fechas.
- Solo muestra registros con `Number(data.shipout) === 3`.
- Ordena por ID descendente, agrupando parejas twin presentes en el resultado.
- Conserva búsqueda por nombre de isotanque, CCO, y visualización previa.
- Checkbox en primera columna. Selección individual o de todos los resultados visibles.
- Selección persistente al buscar, pero se descartan selecciones fuera de un rango recargado.
- Modal de barcos cargados desde `ShipService.getAll()`; `CcoService.getAll()` se reserva para isotanques (son entidades distintas).
- Guardar llama una sola RPC atómica y refresca la lista; los registros asignados dejan de verse.
- El servidor valida que todos los registros seleccionados sigan en shipout=3, para evitar actualizaciones parciales por cambios concurrentes.

## Consideraciones

- El servicio original `WithdrawnService` y `ShipService` no estaban en el ZIP fuente; se incluyen instrucciones y un método para integrar, no se reemplazan esos servicios.
- La función SQL presupone tabla `public.withdrawn`, PK `id bigint` compatible y `data jsonb`.
- Revisar los permisos de la función en PostgreSQL/PostgREST: solo usuarios autorizados deben poder asignar barcos.
- No se ha ejecutado compilación completa porque no se dispone del proyecto Angular entero.
