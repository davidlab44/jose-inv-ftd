import { Component } from '@angular/core';
import { MenuController,AlertController,Config,LoadingController,ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Subject,forkJoin } from 'rxjs';
import { ConferenceData } from '../../../../providers/conference-data';
import { UtilService } from '../../../../services/util.service';
import { CcoMap } from '../../../../interfaces/cco';
import { CcoService } from '../../../../services/cc/cco.service';
import { IoService } from '../../../../services/io/io.service';
import { WdnService } from '../../../../services/wdn/wdn.service';

type LocationKey='empty'|'sai'|'tsai'|'full'|'inb'|'ctg';
interface LocationEvent { key:LocationKey; date:string; timestamp:number; source:'io'|'wdn'; record:any; }
interface LocationData { empty:boolean; sai:boolean; tsai:boolean; full:boolean; inb:boolean; ctg:boolean; }
@Component({ selector:'app-getall',templateUrl:'./getall.html',styleUrls:['./getall.scss'] })
export class GetallPage {
  ccoMap:CcoMap={};
  ios:boolean=false;
  showSearchbar:boolean=true;
  searchSubject=new Subject<string>();
  ccoList:any[]=[];
  ioList:any[]=[];
  wdnList:any[]=[];
  fltCcoList:any[]=[];
  hash:string|null=null;
  loading=false;
  errorMessage='';
  readonly columns:{key:LocationKey;label:string}[]=[
    {key:'sai',label:'SAI'},
    {key:'tsai',label:'En tránsito SAI'},
    {key:'empty',label:'Puerto CTG vacío'},
    {key:'ctg',label:'CTG'},
    {key:'inb',label:'INBEMETAL'},
    {key:'full',label:'Puerto CTG lleno'}
  ];
  constructor(
    public alertCtrl:AlertController,
    public confData:ConferenceData,
    public loadingCtrl:LoadingController,
    public modalCtrl:ModalController,
    public router:Router,
    public config:Config,
    private utilService:UtilService,
    private ccoService:CcoService,
    private ioService:IoService,
    private wdnService:WdnService,
    public menu:MenuController
  ) {}
  ionViewWillEnter():void { this.loadCco(); }
  loadCco():void {
    this.loading=true;
    this.errorMessage='';
    forkJoin({cco:this.ccoService.getAll(),io:this.ioService.getAll(),wdn:this.wdnService.getAll()}).subscribe({
      next:r=>{
        this.ccoList=Array.isArray(r.cco)?r.cco:[];
        this.ioList=Array.isArray(r.io)?r.io:[];
        this.wdnList=Array.isArray(r.wdn)?r.wdn:[];
        this.rebuildList();
        this.loading=false;
      },
      error:err=>{ this.loading=false; this.errorMessage='No fue posible cargar los registros.'; console.error(err); }
    });
  }
  loadIo():void { this.ioService.getAll().subscribe({
    next:r=>{ this.ioList=Array.isArray(r)?r:[]; this.rebuildList(); },
    error:err=>console.error('Error loading io',err)
  }); }
  loadWdn():void { this.wdnService.getAll().subscribe({
    next:r=>{ this.wdnList=Array.isArray(r)?r:[]; this.rebuildList(); },
    error:err=>console.error('Error loading wdn',err)
  }); }
  onSearch(text:string):void { this.hash=text||null; this.searchSubject.next(text||''); this.rebuildList(); }
  private emptyLocation():LocationData {
    return {empty:false,sai:false,tsai:false,full:false,inb:false,ctg:false};
  }
  private sameCco(value:any,name:any):boolean {
    return value!=null && name!=null && String(value).trim()===String(name).trim();
  }
  private event(key:LocationKey,value:any,source:'io'|'wdn',record:any):LocationEvent|null {
    if (!value) return null;
    const timestamp=new Date(value).getTime();
    if (!Number.isFinite(timestamp)) return null;
    return {key,date:String(value),timestamp,source,record};
  }
  private getEvents(name:any):LocationEvent[] {
    const events:LocationEvent[]=[];
    const add=(key:LocationKey,value:any,source:'io'|'wdn',record:any):void=>{
      const event=this.event(key,value,source,record);
      if (event) events.push(event);
    };
    this.ioList.filter(item=>this.sameCco(item?.data?.id_cco,name)).forEach(item=>{
      add('inb',item?.data?.date||item?.updated_at||item?.created_at,'io',item);
    });
    this.wdnList.filter(item=>this.sameCco(item?.data?.id_cco,name)).forEach(item=>{
      const data=item.data||{};
      add('ctg',data.date,'wdn',item);
      add('empty',data.datein,'wdn',item);
      if (!data.dateout) return;
      const shipout=Number(data.shipout);
      if (!Number.isFinite(shipout)) return;
      if (shipout===0) { add('full',data.dateout,'wdn',item); return; }
      if (shipout>0) {
        const elapsed=Date.now()-new Date(data.dateout).getTime();
        const key:LocationKey=elapsed>=2*24*60*60*1000?'sai':'tsai';
        add(key,data.dateout,'wdn',item);
      }
    });
    return events;
  }
  rebuildList():void {
    const term=(this.hash||'').trim().toLowerCase();
    this.fltCcoList=this.ccoList.filter(item=>{
      if (!term) return true;
      return Object.values(item?.data||{}).some(value=>String(value).toLowerCase().includes(term));
    }).map(item=>{
      const events=this.getEvents(item?.data?.name);
      const sorted=[...events].sort((a,b)=>b.timestamp-a.timestamp);
      const latest=sorted[0];
      const lct=this.emptyLocation();
      if (latest) lct[latest.key]=true;
      return {...item,data:{...item.data,lct,lctEvents:events,lctLatest:latest||null}};
    });
  }
  getCount(key:LocationKey):number {
    return this.fltCcoList.filter(item=>item.data.lct[key]).length;
  }
  trackById(index:number,item:any):any { return item.id??index; }
  patchItem(item:any):void { console.log('item to patch',item); }
}
