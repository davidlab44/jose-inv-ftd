import { Component, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, IonList, LoadingController, ModalController, ToastController, Config } from '@ionic/angular';
import { ConferenceData } from '../../../../providers/conference-data';
import { UserData } from '../../../../providers/user-data';
import { OpportunityService } from '../../../../services/opportunity.service';
import { PosOrderService } from '../../../../services/pos-order.service';
import { TableService } from '../../../../services/table.service';
import { environment } from '../../../../../environments/environment';
import { ActivatedRoute } from '@angular/router'
import { Session } from '../../../../interfaces/session';
import { SessionService } from '../../../../services/session.service';
import { UtilService } from '../../../../services/util.service';
import { ProductService } from '../../../../services/product.service';
import { BarcodeService } from '../../../../services/barcode.service';
import { CategoryService } from '../../../../services/category.service';
import { UmService } from '../../../../services/um.service';
import { Product } from '../../../../interfaces/product';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { DateService } from '../../../../services/local/date.service';
import { RexService } from '../../../../services/rex.service';
import { ProdrexService } from '../../../../services/prodrex.service';
import { UserService } from '../../../../services/user.service';
import { ReplenishmentService } from '../../../../services/replenishment/replenishment.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PhotoService } from '../../../../services/asset/photo.service';


@Component({
  selector: 'page-post',
  templateUrl: 'post.html',
  styleUrls: ['./post.scss'],
})
export class AssetSupplyPostPage {

  ios: boolean;
  hasOwner:boolean=false;
  segment = 'all';
  showSearchbar: boolean;
  opportunities = [];
  storedObject: any;
  posOrders: any[] = [];
  posOrderLineList: any[] = [];
  pendingCommands: any[] = [];
  deliveredList: any[] = [];
  filteredProductList: any[] = [];
  maxQtyDeliveredItems: any[] = [];
  queryText:any
  mesas: any[] = [];
  activeSession: Session | null = null;
  sessionId: number | null = null;
  searchSubject = new Subject<string>();
  todayDate:any;
  form!: FormGroup;
  replenishmentList: any[] = [];

  uploadProgress = 0;
  uploadedUrl: string | null = null;
  uploading = false;

  constructor(
    private barcodeService: BarcodeService,
    public alertCtrl: AlertController,
    public confData: ConferenceData,
    public loadingCtrl: LoadingController,
    public modalCtrl: ModalController,
    public router: Router,
    public toastCtrl: ToastController,
    public user: UserData,
    public config: Config,
    private opportunityService: OpportunityService,
    private posOrderService: PosOrderService,
    private tableService: TableService,
    private route: ActivatedRoute,
    private sessionService:SessionService,
    private utilService:UtilService,
    private productService:ProductService,
    private categoryService:CategoryService,
    private umService:UmService,
    private dateService: DateService,
    private rexService: RexService,
    private prodrexService: ProdrexService,
    private userService: UserService,
    private fb: FormBuilder ,
    private replenishmentService : ReplenishmentService,
    private photoService: PhotoService
  ) {}

  hash:string='';
  table:any
  rexDocument:any;

  ngOnInit() {
    this.loadCategories();
    this.loadUms();
    this.form = this.fb.group({
      name: [''],
      um: [0],
    });
    const ahora = new Date();
    this.todayDate=this.formatFechaLatam(ahora);
    this.displayLast();
  }
 
  lastAsset:any;
  displayLast() {
    this.productService.getAll().subscribe({
      next: (response) => {
        this.lastAsset = response.reduce((max, item) =>
          item.id > max.id ? item : max
        );
      }
    });
  }

  guardar() {
    const data: any = this.form.value;
    data.categ = [data.category];
    data.img = this.uploadedUrl; 
    delete data.category;
    console.log('Product to post =>', data);
    this.productService.post(data).subscribe({
      next: (response) => {
        console.log("product post response", response);
        if(response && response.length>0){
          this.utilService.presentToast(response.toString())
          this.router.navigate(['/app/tabs/asset-supply-readprdct'],   { replaceUrl: true });    
        }
      }
    });
  }

  slideOpts = {
    initialSlide: 0,
    slidesPerView: 1,
    speed: 300
  };

  updateSchedule(){}

  productListCaos:any[]=[];
  ionViewWillEnter() {
    console.log('[SEARCH][1] ionViewWillEnter -> solicitando productListCaos');

    this.productService.getCachedOrServer().subscribe({
      next: (data) => {
        console.log('[SEARCH][2] productos recibidos -> cantidad:', data?.length ?? 0);
        console.log('[SEARCH][2.1] productListCaos recibido:', data);

        this.productListCaos = data || [];
        this.filteredProductList = [];

        console.log('[SEARCH][3] productListCaos asignado -> cantidad:', this.productListCaos.length);
      },
      error: (err) => {
        console.error('[SEARCH][ERROR] error cargando productListCaos:', err);
      }
    });
  }

  prodrexList:any[]=[];
  ionViewDidEnter() {
    this.prodrexService.getAll().subscribe({
      next: response=>{
        this.prodrexList=response;
        console.log("getProdRexList",response)
      }
    })
  }

  searchProducts(hash: string, productList: any[]): any[] {
    console.log('--------------------------------------------------');
    console.log('[SEARCH][6] searchProducts() INICIO');
    console.log('[SEARCH][6.1] texto recibido:', hash);
    console.log('[SEARCH][6.2] lista recibida -> cantidad:', productList?.length ?? 0);

    const term = (hash || '').trim().toLowerCase();
    console.log('[SEARCH][6.3] término normalizado:', term);

    if (!term) {
      console.log('[SEARCH][6.4] término vacío -> retorno []');
      return [];
    }

    const matches = (productList || []).filter((product, index) => {
      const name = product?.name;
      const validName = typeof name === 'string';
      const match = validName && name.toLowerCase().includes(term);

      if (match) {
        console.log(`[SEARCH][7] MATCH index=${index} name=`, name, 'producto=', product);
      }

      return match;
    });

    console.log('[SEARCH][8] coincidencias totales antes de limitar:', matches.length);

    const visibleResults = matches.slice(0, 20);
    console.log('[SEARCH][9] resultados visibles (máximo 20) -> cantidad:', visibleResults.length);
    console.log('[SEARCH][9.1] resultados visibles:', visibleResults);
    console.log('[SEARCH][6] searchProducts() FIN');

    return visibleResults;
  }

  onSearch(text: string | null | undefined) {
    console.log('==================================================');
    console.log('[SEARCH][4] ionInput recibido:', text);

    const value = text ?? '';
    console.log('[SEARCH][4.1] value después de normalizar null/undefined:', value);

    this.hash = value;
    console.log('[SEARCH][4.2] this.hash actualizado:', this.hash);

    this.searchSubject.next(value);
    console.log('[SEARCH][4.3] searchSubject.next enviado:', value);

    console.log('[SEARCH][5] ejecutando búsqueda sobre productListCaos -> cantidad:', this.productListCaos.length);
    this.filteredProductList = this.searchProducts(value, this.productListCaos);

    console.log('[SEARCH][10] filteredProductList actualizado -> cantidad:', this.filteredProductList.length);
    console.log('[SEARCH][10.1] filteredProductList:', this.filteredProductList);
  }

  selectProduct(p: any) {
    console.log('##################################################');
    console.log('[SEARCH][11] CLICK / selección recibida');
    console.log('[SEARCH][11.1] seleccionado:', p);
    console.log('seleccionado', p);

    this.hash = p?.name ?? '';
    console.log('[SEARCH][12] buscador actualizado con nombre:', this.hash);

    this.filteredProductList = [];
    console.log('[SEARCH][13] lista de resultados limpiada:', this.filteredProductList);
    console.log('[SEARCH][14] PROCESO DE BÚSQUEDA/SELECCIÓN TERMINADO');
    console.log('##################################################');
  }

  formatFechaLatam(dateInput: string | Date | number): string {
    if (!dateInput) return '';
    const date = new Date(dateInput);
    const opciones: Intl.DateTimeFormatOptions = {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    };
    const fechaTexto = new Intl.DateTimeFormat('es-ES', opciones).format(date);
    let horas = date.getHours();
    const minutos = String(date.getMinutes()).padStart(2, '0');
    const segundos = String(date.getSeconds()).padStart(2, '0');
    const ampm = horas >= 12 ? 'PM' : 'AM';
    horas = horas % 12;
    if (horas === 0) horas = 12; // 12 AM o 12 PM en lugar de 0
    const horasTexto = String(horas).padStart(2, '0');
    return `${fechaTexto} ${horasTexto}:${minutos}:${segundos} ${ampm}`;
  }

  categories: any[] = [];    
  loadCategories() { 
      this.categoryService.getAllCategories().subscribe({ 
        next: (res) => {       
          this.categories = res;          
          this.categoryService.saveCategoriesToLocal(res); // Guarda en localStorage 
        }, 
        error: (err) => {      
          console.error('❌ Error al cargar categorías:', err); 
          this.categories = this.categoryService.getCategoriesFromLocal(); 
        } 
      }); 
   }   
       
   ums: any[] = []; 
   loadUms() {                
     this.umService.getAllUms().subscribe({ 
        next: (res) => {       
          console.log('Ums:', res);    
          this.ums = res; 
          this.umService.saveUmsToLocal(res); 
        }, 
        error: (err) => {      
          console.error('Error al cargar categorías:', err); 
          this.ums = this.umService.getUmsFromLocal(); 
        } 
      }); 
   }     




}
