Versión data.end - lote de imágenes y observaciones globales

- Las imágenes se suben inmediatamente a MinIO, pero el botón Guardar fotografías registra
  un único objeto {date, imgs, status:'c', note} en data.end por lote.
- La edición conserva la sustitución de URL, dentro del grupo ya registrado o pendiente.
- Eliminar una foto guardada conserva la trazabilidad con status:'deleted'.
- data.ini permanece intacto.
- DateService se importa desde src/app/services/date.service.ts. Si el servicio está en
  otra carpeta, ajustar SOLAMENTE esa ruta de importación en patch.ts.
- Verificar compilación en el proyecto y probar el endpoint antes de producción.
